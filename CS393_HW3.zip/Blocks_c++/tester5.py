print("help")

print("newfs hello.dev 509 4092")
print("mount hello.dev")
print("iNodeMapFull")
i = 50
while i > 0:
	print("allociNode")
	i = i - 1
print("iNodeMapFull")
print("unmount")
print("mount hello.dev")
print("iNodeMapFull")
print("unmount")

print("quit")