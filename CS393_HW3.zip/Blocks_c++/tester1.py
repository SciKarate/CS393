print("help")

print("newfs hello.dev 16 8")
print("mount hello.dev")
print("blockMapFull")
print("setBlock 4\nsetBlock 6\nsetBlock 2\nsetBlock 14")
print("allocBlock\nallocBlock\nallocBlock\nfreeBlock 1")
print("blockMapFull")
print("unmount")
print("mount hello.dev")
print("blockMapFull")
print("unmount")

print("quit")