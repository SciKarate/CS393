print("help")

print("newfs hello.dev 512 4096")
print("mount hello.dev")
print("iNodeMapFull")
print("setiNode 2")
print("allociNode")
print("allociNode")
print("freeiNode 0\nsetiNode 3\nfreeiNode 2")
print("setiNode 24");
print("iNodeMapFull")
print("unmount")
print("mount hello.dev")
print("iNodeMapFull")
print("unmount")

print("quit")